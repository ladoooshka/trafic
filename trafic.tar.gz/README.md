#Python 3.8.10

#If you need stop script make the dir 'dead' in /home/v.maksimova
#Mb need some changes in file way
