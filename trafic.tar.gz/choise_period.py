import datetime
import os
import io
import sqlalchemy

#here will be part with select from tables and create some variables for analitics